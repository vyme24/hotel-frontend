// settings/NotificationSettings.jsx
const NotificationSettings = () => {
    return (
        <div className="container-fluid">
            <h1>Notification Settings Page</h1>
        </div>
    );
}
export default NotificationSettings;