// settings/HotelSettings.jsx
const HotelSettings = () => {
    return (
        <div className="container-fluid">
            <h1>Hotel Settings Page</h1>
        </div>
    );
}
export default HotelSettings;