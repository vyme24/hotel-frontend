// settings/PoliciesSettings.jsx
const PoliciesSettings = () => {
    return (
        <div className="container-fluid">
            <h1>Policies Settings Page</h1>
        </div>
    );
}
export default PoliciesSettings;