// settings/GeneralSettings.jsx
const GeneralSettings = () => {
    return (
        <div className="container-fluid">
            <h1>General Settings Page</h1>
        </div>
    );
}
export default GeneralSettings;