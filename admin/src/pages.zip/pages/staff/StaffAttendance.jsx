// staff/StaffAttendance.jsx
const StaffAttendance = () => {
    return (
        <div className="container-fluid">
            <h1>Staff Attendance Page</h1>
        </div>
    );
}
export default StaffAttendance;