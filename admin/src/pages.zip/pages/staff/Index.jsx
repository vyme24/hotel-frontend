// staff/Index.jsx
const Staff = () => {
    return (
        <div className="container-fluid">
            <h1>Staff Page</h1>
        </div>
    );
}
export default Staff;