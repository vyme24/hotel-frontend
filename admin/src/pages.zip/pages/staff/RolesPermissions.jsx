// staff/RolesPermissions.jsx
const RolesPermissions = () => {
    return (
        <div className="container-fluid">
            <h1>Roles & Permissions Page</h1>
        </div>
    );
}
export default RolesPermissions;