// marketing/Offers.jsx
const Offers = () => {
    return (
        <div className="container-fluid">
            <h1>Offers Page</h1>
        </div>
    );
}
export default Offers;