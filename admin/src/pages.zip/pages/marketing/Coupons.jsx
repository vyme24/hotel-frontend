// marketing/Coupons.jsx
const Coupons = () => {
    return (
        <div className="container-fluid">
            <h1>Coupons Page</h1>
        </div>
    );
}
export default Coupons;