// bookings/CheckInToday.jsx
const CheckInToday = () => {
    return (
        <div className="container-fluid">
            <h1>Check In Today Page</h1>
        </div>
    );
}
export default CheckInToday;