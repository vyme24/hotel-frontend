// bookings/NewBookings.jsx
const NewBookings = () => {
    return (
        <div className="container-fluid">
            <h1>New Bookings Page</h1>
        </div>
    );
}
export default NewBookings;