// bookings/CancelledBookings.jsx
const CancelledBookings = () => {
    return (
        <div className="container-fluid">
            <h1>Cancelled Bookings Page</h1>
        </div>
    );
}
export default CancelledBookings;