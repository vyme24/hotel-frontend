// bookings/ConfirmedBookings.jsx
const ConfirmedBookings = () => {
    return (
        <div className="container-fluid">
            <h1>Confirmed Bookings Page</h1>
        </div>
    );
}
export default ConfirmedBookings;