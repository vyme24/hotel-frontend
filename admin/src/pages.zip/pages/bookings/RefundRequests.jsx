// bookings/index.jsx
const Bookings = () => {
    return (
        <div className="container-fluid">
            <h1>Bookings Page</h1>
        </div>
    );
}
export default Bookings;