// bookings/BookingDetails.jsx
const BookingDetails = () => {
    return (
        <div className="container-fluid">
            <h1>Booking Details Page</h1>
        </div>
    );
}
export default BookingDetails;