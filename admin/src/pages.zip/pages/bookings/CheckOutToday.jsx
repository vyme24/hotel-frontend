// bookings/CheckOutToday.jsx
const CheckOutToday = () => {
    return (
        <div className="container-fluid">
            <h1>Check Out Today Page</h1>
        </div>
    );
}
export default CheckOutToday;