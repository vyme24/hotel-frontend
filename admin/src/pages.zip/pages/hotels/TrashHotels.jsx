// hotels/TrashHotels.jsx
const TrashHotels = () => {
    return (
        <div className="container-fluid">
            <h1>Trash Hotels Page</h1>
        </div>
    );
}
export default TrashHotels;