// hotels/PendingHotels.jsx
const PendingHotels = () => {
    return (
        <div className="container-fluid">
            <h1>Pending Hotels Page</h1>
        </div>
    );
}
export default PendingHotels;