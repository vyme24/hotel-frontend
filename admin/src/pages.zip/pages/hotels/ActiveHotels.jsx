// hotels/ActiveHotels.jsx
const ActiveHotels = () => {
    return (
        <div className="container-fluid">
            <h1>Active Hotels Page</h1>
        </div>
    );
}
export default ActiveHotels;