// hotels/InactiveHotels.jsx
const InactiveHotels = () => {
    return (
        <div className="container-fluid">
            <h1>Inactive Hotels Page</h1>
        </div>
    );
}
export default InactiveHotels;