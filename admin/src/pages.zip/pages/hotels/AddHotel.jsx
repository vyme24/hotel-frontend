// hotels/AddHotel.jsx
const AddHotel = () => {
    return (
        <div className="container-fluid">
            <h1>Add Hotel Page</h1>
        </div>
    );
}
export default AddHotel;