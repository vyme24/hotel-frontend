// hotels/FeaturedHotels.jsx
const FeaturedHotels = () => {
    return (
        <div className="container-fluid">
            <h1>Featured Hotels Page</h1>
        </div>
    );
}
export default FeaturedHotels;