// reviews/PendingReviews.jsx
const PendingReviews = () => {
    return (
        <div className="container-fluid">
            <h1>Pending Reviews Page</h1>
        </div>
    );
}
export default PendingReviews;