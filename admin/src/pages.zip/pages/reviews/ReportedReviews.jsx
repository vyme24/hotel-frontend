// reviews/ReportedReviews.jsx
const ReportedReviews = () => {
    return (
        <div className="container-fluid">
            <h1>Reported Reviews Page</h1>
        </div>
    );
}
export default ReportedReviews;