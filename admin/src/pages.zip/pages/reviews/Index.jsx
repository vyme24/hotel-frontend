// reviews/Index.jsx
const Reviews = () => {
    return (
        <div className="container-fluid">
            <h1>Reviews Page</h1>
        </div>
    );
}
export default Reviews;