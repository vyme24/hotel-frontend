// rooms/AvailableRooms.jsx
const AvailableRooms = () => {
    return (
        <div className="container-fluid">
            <h1>Available Rooms Page</h1>
        </div>
    );
}
export default AvailableRooms;