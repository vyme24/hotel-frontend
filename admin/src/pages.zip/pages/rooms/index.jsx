// rooms/index.jsx
const Rooms = () => {
    return (
        <div className="container-fluid">
            <h1>Rooms Page</h1>
        </div>
    );
}
export default Rooms;