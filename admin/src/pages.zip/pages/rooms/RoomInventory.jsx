// rooms/RoomInventory.jsx
const RoomInventory = () => {
    return (
        <div className="container-fluid">
            <h1>Room Inventory Page</h1>
        </div>
    );
}
export default RoomInventory;