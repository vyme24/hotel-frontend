// rooms/InactiveRooms.jsx
const InactiveRooms = () => {
    return (
        <div className="container-fluid">
            <h1>Inactive Rooms Page</h1>
        </div>
    );
}
export default InactiveRooms;