// rooms/RoomTypes.jsx
const RoomTypes = () => {
    return (
        <div className="container-fluid">
            <h1>Room Types Page</h1>
        </div>
    );
}
export default RoomTypes;