// rooms/SoldOutRooms.jsx
const SoldOutRooms = () => {
    return (
        <div className="container-fluid">
            <h1>Sold Out Rooms Page</h1>
        </div>
    );
}
export default SoldOutRooms;