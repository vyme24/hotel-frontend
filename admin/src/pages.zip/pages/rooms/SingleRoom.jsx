// rooms/SingleRoom.jsx
const SingleRoom = () => {
    return (
        <div className="container-fluid">
            <h1>Single Room Page</h1>
        </div>
    );
}
export default SingleRoom;