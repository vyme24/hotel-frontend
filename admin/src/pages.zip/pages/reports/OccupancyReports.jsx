// reports/OccupancyReports.jsx
const OccupancyReports = () => {
    return (
        <div className="container-fluid">
            <h1>Occupancy Reports Page</h1>
        </div>
    );
}
export default OccupancyReports;