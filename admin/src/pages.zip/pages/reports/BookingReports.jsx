// reports/BookingReports.jsx
const BookingReports = () => {
    return (
        <div className="container-fluid">
            <h1>Booking Reports Page</h1>
        </div>
    );
}
export default BookingReports;