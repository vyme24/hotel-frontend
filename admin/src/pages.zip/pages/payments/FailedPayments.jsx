// payments/FailedPayments.jsx
const FailedPayments = () => {
    return (
        <div className="container-fluid">
            <h1>Failed Payments Page</h1>
        </div>
    );
}
export default FailedPayments;