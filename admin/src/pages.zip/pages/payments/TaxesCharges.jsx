// payments/TaxesCharges.jsx
const TaxesCharges = () => {
    return (
        <div className="container-fluid">
            <h1>Taxes & Charges Page</h1>
        </div>
    );
}
export default TaxesCharges;