// payments/Refunds.jsx
const Refunds = () => {
    return (
        <div className="container-fluid">
            <h1>Refunds Page</h1>
        </div>
    );
}
export default Refunds;