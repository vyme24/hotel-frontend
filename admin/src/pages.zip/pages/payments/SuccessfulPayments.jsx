// payments/SuccessfulPayments.jsx
const SuccessfulPayments = () => {
    return (
        <div className="container-fluid">
            <h1>Successful Payments Page</h1>
        </div>
    );
}
export default SuccessfulPayments;