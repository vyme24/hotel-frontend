// payments/Invoice.jsx
const Invoice = () => {
    return (
        <div className="container-fluid">
            <h1>Invoice Page</h1>
        </div>
    );
}
export default Invoice;