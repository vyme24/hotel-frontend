// guests/CurrentGuests.jsx
const CurrentGuests = () => {
    return (
        <div className="container-fluid">
            <h1>Current Guests Page</h1>
        </div>
    );
}
export default CurrentGuests;