// guests/GuestHistory.jsx
const GuestHistory = () => {
    return (
        <div className="container-fluid">
            <h1>Guest History Page</h1>
        </div>
    );
}
export default GuestHistory;