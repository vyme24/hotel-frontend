// guests/GuestDetails.jsx
const GuestDetails = () => {
    return (
        <div className="container-fluid">
            <h1>Guest Details Page</h1>
        </div>
    );
}
export default GuestDetails;